#load packages
library(igraph)
library(bibliometrix)
library(ggraph)
library(ggplot2)
library(tidygraph)
library(dplyr)
library(oaqc)

#load web of science search results
#https://www.webofscience.com/wos/woscc/summary/a1485ee6-27f0-4bf7-ae19-fc25831c4a0f-9482873b/relevance/1(overlay:export/exp)
setwd("C://Users//xo84dev//Nextcloud//WaVe//KickOff//literature review")

f_1 <- "1.txt"
f_2 <- "2.txt"
f_3 <- "3.txt"
f_4 <- "4.txt"
#convert plaintext to dataframe with bibliometrix
M_1 <- convert2df(file = f_1, dbsource = 'wos', format = "plaintext")
M_2 <- convert2df(file = f_2, dbsource = 'wos', format = "plaintext")
M_3 <- convert2df(file = f_3, dbsource = 'wos', format = "plaintext")
M_4 <- convert2df(file = f_4, dbsource = 'wos', format = "plaintext")

# Zusammenführen der Datensätze
combined <- Reduce(function(x, y) merge(x, y, all = TRUE), list(M_1, M_2, M_3, M_4))

# Identifizieren der Spalten, die in allen Datensätzen enthalten sind
common_cols <- names(combined)[apply(combined, 2, function(col) all(!is.na(col)))]

# Auswahl der gemeinsamen Spalten im zusammengeführten Datensatz
combined <- combined[, common_cols]

M1 <- cbind(M_1$AU, M_1$TI, M_1$WC, M_1$AB, M_1$DE, M_1$ID)
M2 <- cbind(M_2$AU, M_2$TI, M_2$WC, M_2$AB, M_2$DE, M_2$ID)
M3 <- cbind(M_3$AU, M_3$TI, M_3$WC, M_3$AB, M_3$DE, M_3$ID)
M4 <- cbind(M_4$AU, M_4$TI, M_4$WC, M_4$AB, M_4$DE, M_4$ID)


M<-rbind(M1, M2, M3, M4)
colnames(M) <- c("AU", "TI", "WC", "AB", "DE", "ID")
M<-data.frame(M)

###bibliometrix
results <- biblioAnalysis(combined, sep = ";")
#checking for missing data
missingData(results)

#summary
S_complete <- summary(object = results, k = 10, pause =FALSE)

#article production
production <- S_complete$AnnualProduction
colnames(production)<- c("Year", "Articles")
production <- subset(production, Year < max(production$Year))

# Plot erstellen
production$Year <- as.numeric(as.character(production$Year))

p_production <- ggplot(production) +
  aes(x = Year, y = Articles) +
  labs(title = "Annual Scientific Production")+
  geom_point(color = "#2F5597") +
  geom_line(aes(group = 1),color = "#2F5597", size = 1)+
  theme(panel.background = element_rect(fill = "white", colour = "grey50"),plot.title = element_text(hjust = 0.5)) +
  scale_x_continuous(breaks = seq(min(production$Year), max(production$Year), by = 5))

p_production

##network with igraph
# Combine keywords from different columns
#keywords <- unique(M2020$DE)
keywords <- M$DE
# Keywords in einzelne Wörter aufteilen
keyword_list <- strsplit(keywords, "; ")


# create igraph obeject
make_graph <- function(keyword_list){
  # Max number of keywords
  max_keywords <- max(sapply(keyword_list, length))
  
  # Create keyword matrices
  keyword_matrix <- matrix("", nrow = length(keyword_list), ncol = max_keywords)
  
  # Fill keyword matrices
  for (i in 1:length(keyword_list)) {
    keywords <- keyword_list[[i]]
    keyword_matrix[i, 1:length(keywords)] <- keywords
  }
  
  # Convert matrices to data frames
  keyword_df <- as.data.frame(keyword_matrix)
  
  # Set column names
  colnames(keyword_df) <- paste0("Keyword", 1:max_keywords)
  
  # Remove NA rows
  keyword_df <- keyword_df[complete.cases(keyword_df), ]
  
  # Create the network objects
  network <- graph_from_data_frame(d = keyword_df, directed = FALSE)
  
  # Create graph with popularity
  graph <- as_tbl_graph(keyword_df)
  graph <- as_tbl_graph(keyword_df) %>% 
    mutate(Popularity = degree(graph))
  return(graph)
}

graph <- make_graph(keyword_list)


# plot using ggraph
#plot1 <- ggraph(graph, layout = 'fr') + 
#  geom_edge_fan(aes(alpha = after_stat(index)), show.legend = FALSE) + 
#  geom_node_point(aes(size = Popularity)) + 
#  theme_graph(foreground = 'steelblue', fg_text_colour = 'white', base_family = "sans")
#plot1

#isolierte Knoten rausfiltern
isolated_nodes <- which(degree(graph) < 2)

# Entferne die isolierten Knoten aus dem Netzwerk
graph_noniso <- delete.vertices(graph, isolated_nodes)

#plot2 <- ggraph(graph_noniso, layout = 'fr') + 
#  geom_edge_fan(aes(alpha = after_stat(index)), show.legend = FALSE) + 
#  geom_edge_link(edge_width = 1, show.legend = FALSE)+
#  geom_node_point(aes(size = Popularity)) + 
#  geom_node_text(aes(filter = (Popularity >= 2.5), label = name, size =0.8))  
#  theme_graph(foreground = 'steelblue', fg_text_colour = 'white', base_family = "sans")
#plot2

###clustering

# compute a clustering for node colors
g <-as.undirected(graph_noniso)
V(g)$clu <- as.character(membership(cluster_louvain(g)))

# compute degree as node size
V(g)$size <- degree(g)

isolated_nodes <- which(degree(g) < 2)

# Entferne die isolierten Knoten aus dem Netzwerk
g2 <- delete.vertices(g, isolated_nodes)

g2 <- delete.vertices(g2, V(g2)$name %in% c("WATER-ENERGY-FOOD NEXUS", "ENERGY POLICY", "WATER DEMAND MANAGEMENT"))

nice_palette <- colorRampPalette(c("#FF7575", "#FFA575", "#FFD275", "#FFFF75", "#D2FF75", "#A5FF75", "#75FF75", "#75FFA5", "#75FFD2", "#75FFFF", "#75D2FF", "#75A5FF", "#7575FF", "#A575FF", "#D275FF", "#FF75FF", "#FF75D2", "#FF75A5", "#FF7575"))(17)

###

# Find the largest connected component
largest_component <- clusters(g2)$membership
connected_graph <- induced_subgraph(g2, which(largest_component == which.max(table(largest_component))))

plot5 <-ggraph(connected_graph, layout = "centrality", cent =graph.strength(connected_graph)) +
  geom_edge_link(edge_colour = "grey66", n=20) +
  geom_node_point(aes( fill = clu, size = size), shape = 21) +
  scale_fill_manual(values = nice_palette) +
  geom_node_text(aes(filter = (size >= 10),size =3, label =name), repel= TRUE) +
  scale_edge_width(range = c(0.2, 10)) +
  scale_size(range = c(2, 10)) +
  theme_graph() +
  theme(legend.position = "none")+
  coord_fixed()
plot5
